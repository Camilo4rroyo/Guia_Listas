package com.mycompany.listabasica;

import java.util.Scanner;

/**
 * EJERCICIO 1 — Lista Enlazada Básica (enteros)
 *
 * Conceptos ilustrados:
 *   - Clase auto-referenciada : Nodo (contiene una referencia a otro Nodo)
 *   - Nodo                    : unidad básica con dato + enlace
 *   - Campo de enlace         : campo "enlace" dentro de cada Nodo
 *   - Enlace                  : la conexión entre nodos consecutivos
 */
public class Main {

    public static void main(String[] args) {

        // ── 1. Crear la lista enlazada ─────────────────────────────────────
        ListaEnlazada lista = new ListaEnlazada();

        System.out.println("=== EJERCICIO 1 — LISTA ENLAZADA BÁSICA ===\n");

        // ── 2. Insertar nodos ──────────────────────────────────────────────
        Scanner sc = new Scanner (System.in);
        System.out.println("Ingrese el numero de elementos de la lista: ");
        int tamanolista = sc.nextInt();
        for (int i=0; i<tamanolista; i++){
            System.out.println("Ingrese el elemento en la posicion "+i+" a insertar en la lista: ");
            int inse = sc.nextInt();
            lista.insertar(inse);
        }
        
        lista.mostrar();

        /*
         * Internamente los nodos se ven así:
         *
         *   ┌───────────┐    ┌───────────┐    ┌───────────┐
         *   │ dato: 10  │    │ dato: 20  │    │ dato: 30  │  ...
         *   │ enlace: ──┼───▶│ enlace: ──┼───▶│ enlace: ──┼───▶ null
         *   └───────────┘    └───────────┘    └───────────┘
         *      Nodo 1            Nodo 2            Nodo 3
         *
         *  "enlace" es el CAMPO DE ENLACE → hace que Nodo sea AUTO-REFERENCIADA
         */

        // ── 3. Tamaño ──────────────────────────────────────────────────────
        System.out.println("\n▶ Tamaño de la lista: " + lista.tamanio());

        // ── 4. Buscar ──────────────────────────────────────────────────────
        System.out.println("\nIngrese el elemento a buscar: ");
        int busca = sc.nextInt();
        System.out.println(lista.buscar(busca));

        // ── 5. Eliminar ────────────────────────────────────────────────────
        System.out.println("Ingrese el elemento a eliminar de la lista: ");
        int elim = sc.nextInt();
        lista.eliminar(elim);
        lista.mostrar();

        System.out.println("Ingrese la cabeza de la lista: ");
        int cabelista = sc.nextInt();
        lista.eliminar(cabelista);
        System.out.println("\n▶ Eliminando cabeza...");
        lista.mostrar();


    }
}
