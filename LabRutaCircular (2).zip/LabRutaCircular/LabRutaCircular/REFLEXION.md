# Reflexión — LabRutaCircular

## 1. ¿Por qué no hace falta comprobar `actual.siguiente == null`?

Porque la lista manual es circular: el enlace `siguiente` del último nodo apunta a `primero`, y el enlace `anterior` de `primero` apunta al último nodo. Por eso siempre hay un nodo siguiente y anterior mientras la lista no esté vacía. Un recorrido con `while (aux != null)` no terminaría al llegar al final: nunca se alcanza `null` y se repetiría indefinidamente. Para recorrer una vuelta se debe detener al regresar al nodo de partida, por ejemplo con `do { ... } while (aux != primero)`.

## 2. ¿Qué falla si no se actualiza `primero` al eliminar el primer nodo?

`primero` seguiría apuntando al nodo eliminado. Por ejemplo, si la ruta es A ⇄ B ⇄ C y `actual` es A, al eliminar A los enlaces de B y C se conectan, pero si `primero` no cambia seguirá apuntando a A. Entonces operaciones que usan `primero` podrían incluir la parada eliminada o recorrer una estructura incoherente. En ese caso, `primero` debe pasar a ser B.

## 3. Complejidad temporal

| Operación | Manual (lista circular propia) | Librería (`LinkedList`) |
|---|---:|---:|
| `agregar` | O(1) | O(1) |
| `siguiente` / `anterior` | O(1) | O(1) |
| `saltarNo` / `saltar(n)` | O(min(|n % tamaño|, tamaño)) | O(tamaño) en general, por la rotación de `Collections.rotate` sobre `LinkedList` |
| `eliminarActual` | O(1) | O(1) |

`tiempoTotal()` recorre todas las paradas, por lo que es O(n) en ambas implementaciones. Para `saltar(n)`, la versión manual reduce primero el salto usando el residuo, así evita recorrer vueltas completas innecesarias.

## 4. Ventajas y pérdida de control al usar la librería

`LinkedList` reduce el código que hay que escribir y mantener, y ya implementa los enlaces, la inserción y la eliminación de nodos. Esto disminuye el riesgo de romper accidentalmente la estructura al actualizar referencias. A cambio, se pierde el control directo de cada nodo y sus enlaces; además, la circularidad es lógica: la lista interna sigue teniendo un principio y un final, y el comportamiento circular debe simularse rotando los elementos.

## 5. Parada prioritaria y cola de pendientes

Para una parada prioritaria usaría `java.util.PriorityQueue` si las prioridades se pueden ordenar mediante un criterio (por ejemplo, nivel de urgencia). Para las paradas pendientes usaría `java.util.Queue`, con una implementación como `ArrayDeque`, porque permite encolar al final y atender desde el principio siguiendo el orden de llegada. Si el sistema necesita conservar prioridad y orden de llegada, definiría explícitamente cómo resolver los empates.
